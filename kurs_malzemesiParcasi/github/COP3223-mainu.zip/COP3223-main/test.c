#include <stdio.h>
#include <stdlib.h>
//Homework 2
int main()
{
    printf("\nVALENCE COMMUNITY COLLEGE \nORLANDO FL 10101 \n*************************");
    return 0;
}
