#include<stdio.h>
void main()
{
char a;
int b;
printf("Enter The Character ");
scanf("%c",&a);
b=a;
printf("\nOutput Is =%d ",b);
}