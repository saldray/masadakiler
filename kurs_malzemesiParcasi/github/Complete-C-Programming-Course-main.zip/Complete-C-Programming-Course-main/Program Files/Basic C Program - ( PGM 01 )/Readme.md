<div align="center">
## List of Programs📓

|No.| Program Files        |
|----|:-------------:|
|(01).|Calculate Factorial Of A Given Number |
|(02).| Calculate Percentage Of 5 Subjects      |
|(03).| Calculate Simple Interest      |
|(04).| Check Number Is Positive Or Negative      |
|(05).| Convert a person's name in Abbreviated      |
|(06).| Display Size Of Different Datatype     |
|(07).| Find Area And Circumference Of Circle      |
|(08).| Find Area Of Triangle       |
|(09).| Find Character Is Vowel Or Not      |
|(10).| Find Greater Number Among Given Three Number      | 
|(11).| Find The Gross Salary of an Employee      | 
|(12).| Program To Print Ascii Value Of Character      | 
|(13).| Read Integer (N) And Print First Three Powers (N^1,N^2,N^3)      | 
|(14).| Write a program to accept two num and swap them |

</div>