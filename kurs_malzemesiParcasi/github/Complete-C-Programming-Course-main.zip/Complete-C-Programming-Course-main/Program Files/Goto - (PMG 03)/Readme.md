## List of Programs📓

|No.| Program Files  |
|----|:-------------:|
|(01).|Print Hello 100 times |
|(02).|WAP to display even no from 20 to 500 |
|(03).|WAP to accept a num and Display the sum of all factors of the given number |