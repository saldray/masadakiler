#include <stdio.h>
#include <stdlib.h>
//Homework 2 
int main()
{   
    int f = 27; 
    float c;
    c = (f - 32) / 1.8;
    printf("%d F is %.2f C", f, c);
    return 0;
}
