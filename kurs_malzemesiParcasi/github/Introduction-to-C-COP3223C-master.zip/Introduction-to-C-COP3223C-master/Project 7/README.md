Source: gala.c<br />
Score: <b>100/100</b><br />
Sample Input: gala.txt<br />
Sample Output: gala.out<br />
Scaffold File: gala_scaffold.c
