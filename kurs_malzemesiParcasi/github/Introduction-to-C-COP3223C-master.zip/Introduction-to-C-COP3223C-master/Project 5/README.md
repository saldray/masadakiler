Source: auction.c<br />
Score: <b>98/100</b><br />
Sample Input: sampleinput.txt
