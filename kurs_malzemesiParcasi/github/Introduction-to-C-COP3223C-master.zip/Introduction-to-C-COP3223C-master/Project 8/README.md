Source: charityrun.c<br />
Score: <b>90/100</b><br />
Sample Input: race1.txt, race2.txt, race3.txt, race4.txt<br />
Sample Output: race1.out, race2.out, race3.out, race4.out
