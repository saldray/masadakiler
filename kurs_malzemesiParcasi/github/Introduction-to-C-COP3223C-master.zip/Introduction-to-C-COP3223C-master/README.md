# Introduction-to-C-COP3223C
A repo full of all of the projects assigned to me and their sources (my submissions) for my fall semester at UCF.<br />
This was uploaded <b>with permission from my instructor.</b>

All source files are written using the C programming language as taught in class.<br />
Project instructions are provided in .docx and .pdf through Program#.docx and Program#.pdf<br />
<b>I only take credit for the source code provided, all projects and other files are property of their rightful owners.</b>

## Sponsors

* Thank you to [@Amoz3](https://github.com/Amoz3) for sponsoring this project
* Thank you to [@GBerghoff](https://github.com/GBerghoff) for sponsoring this project
* Thank you to [@weweeam](https://github.com/weweeam) for sponsoring this project
