Source: fund.c<br />
Score: <b>50/50</b>
