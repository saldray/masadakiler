Source: fund2.c<br />
Score: <b>50/50</b>
