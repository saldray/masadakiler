/* Nicole Zolnier
My First C Program
5/27/21  
COP 3223 */

#include <stdio.h>

int main (void) {
    printf("Hello World :)\n");
    return 0;
}