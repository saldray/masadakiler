# COP-3223C - Introduction to C Programming
Summer 2021 - UCF

A repository to store my course work and see how my code improves.
This was uploaded with permission from my instructor.

Each folder named "week" contains what it was worked on class that week.
Folders named "assignments" contains the graded assignments, which I hold the copyright for.
