On the terminal: 

```
gcc file.c -o filename
```

or (it will set the filename as "a")

```
gcc file.c
```

Executing:
```
./file.exe
```