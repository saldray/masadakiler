// hello.c
// Chapter 2
// Learn C Programming
//
// Simple "Hello, world!" program.
//
// compile with:
//
//  cc hello.c

#include <stdio.h>

int main()
{
  printf( "Hello, world!\n" );
  return 0;
}

//  <eof>
