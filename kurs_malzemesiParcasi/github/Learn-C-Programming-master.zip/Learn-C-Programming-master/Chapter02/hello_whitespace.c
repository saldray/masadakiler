//  hello_whitespace.c
//  Chapter 2
//  Learn C Programming
//
//  Whitespace gone wild! 
//  Just because you can do a thing does 
//  mean that you must to that thing.
//
//  Don't do what you see here, either.
//
// Compile with:
//
//    cc hello_whitespace.c -Wall -Werror -std=c11
//

#             include                             <stdio.h>


int 
main
(
)
{

  printf 

  ( 

                         "Hello, world!\n" 
  
        )
;

   return 
          0
            ;

}

//  <eof>

