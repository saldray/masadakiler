// array3.h
// Chapter 11
// Learn C Programming
//
// Header file for array3.c
//

  // function prototypes
  
int    findMin( int size , int a[] );
int    findMax( int size , int a[] );

double findMean(   int size , int a[] );
double findStdDev( int size , int a[] );


  // eof
  
