/*
 * hello2.c
 * My first C program with comments.
 * by <your name>
 * created <year>/<month>/<day> 
 *
 * compile with:
 *
 *   cc hello2.c 
 */

#include <stdio.h>

int main()
{
  printf( "Hello, world!\n" );
  return 0;
}

  /* eof */
