#include <stdio.h>

int main()
{
	char text[10];

	printf("Type something: ");
	scanf("%s",text);
	printf("You typed: %s\n",text);

	return(0);
}
