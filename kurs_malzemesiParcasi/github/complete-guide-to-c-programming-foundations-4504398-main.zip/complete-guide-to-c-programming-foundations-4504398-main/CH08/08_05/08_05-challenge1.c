#include <stdio.h>

int main()
{
	char title[] = "Pointers don't intimidate me!\n";

	return 0;
}
