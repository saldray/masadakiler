#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int compare(const void *a, const void *b)
{
	return( *(int *)a - *(int *)b);
}

int main()
{
	// seed the randomizer
	// allocate storage
	// populate the grid with random values, 0 through 99
	// quicksort the grid
	// output the grid

	return 0;
}
