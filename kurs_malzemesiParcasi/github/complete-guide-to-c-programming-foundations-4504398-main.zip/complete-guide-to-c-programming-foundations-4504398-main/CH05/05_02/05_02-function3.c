#include <stdio.h>

int main()
{
	puts("Carefully read these directions!");
	printf("Press any key to continue: ");
	getchar();
	puts("Are you sure you read the directions?");
	printf("Press any key to continue: ");
	getchar();
	puts("Okay. I'm sure you're sure.");
	printf("Press any key to continue: ");
	getchar();

	return(0);
}
