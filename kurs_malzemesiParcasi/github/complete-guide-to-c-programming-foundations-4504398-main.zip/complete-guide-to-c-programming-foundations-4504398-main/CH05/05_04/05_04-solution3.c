#include <stdio.h>

void line(void)
{
	puts("----------------------------------------");
}

int main()
{
	puts("How to Fight Off a Robot Attack");
	line();
	puts("A Survival Guide for the 21st Century");
	line();

	return(0);
}

