#include <stdio.h>

int main()
{
	printf("I am the main() function\n");

	return 0;
}
