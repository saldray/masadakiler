#include <stdio.h>

int main()
{
	puts("Report on Extraterrestrial Activity");
	line(35,'-');

	return(0);
}
