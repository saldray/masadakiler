#include <stdio.h>

int main()
{
	int a;

	for( a = 0 ; a < 10 ; a++ )
	{
		puts("I must do this 10 times");
	}

	return(0);
}

