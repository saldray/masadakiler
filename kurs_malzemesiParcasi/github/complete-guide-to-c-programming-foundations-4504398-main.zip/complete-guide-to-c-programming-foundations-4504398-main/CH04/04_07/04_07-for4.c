#include <stdio.h>

int main()
{
	for(;;)
	{
		printf("I am eternal ");
	}

	return(0);
}

