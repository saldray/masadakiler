#include <stdio.h>

int main()
{
	int a,b;

	for( a=1, b=10 ; a<=10 ; a++, b-- )
		printf("%2d %2d\n",a,b);

	return(0);
}

