#include <stdio.h>

int main()
{
	int a;

	a = 0;
	while( a < 10 )
	{
		puts("I must do this 10 times");
		a++;
	}

	return(0);
}

