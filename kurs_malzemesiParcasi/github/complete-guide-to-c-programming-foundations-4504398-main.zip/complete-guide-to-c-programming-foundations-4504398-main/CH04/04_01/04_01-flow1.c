#include <stdio.h>

int main()
{
	puts("This code runs top-down");
	puts("Each line executed, one after the other");
	puts("Up until the function ends");
	puts("For the main() function, a 'return' ends the flow");

	return 0;
}
