#include <stdio.h>

int main()
{
	int a;

	for(a=1; a<=20; a++)
	{
		puts("Help! I'm trapped in the computer!");
	}

	return(0);
}
