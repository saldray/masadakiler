#include <stdio.h>

int main()
{
	int a;

	a = 6 / 2 * (1 + 2);
	printf("The people who said %d are correct.\n",a);

	return(0);
}
