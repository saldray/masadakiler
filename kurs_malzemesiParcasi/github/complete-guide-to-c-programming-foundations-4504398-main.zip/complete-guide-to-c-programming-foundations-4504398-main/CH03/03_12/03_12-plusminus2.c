#include <stdio.h>

int main()
{
	int a,b;

	a = 50;
	b = 10;

	printf("%d + %d = %d\n",+a,-b,+a+-b);

	return(0);
}

