#include <stdio.h>

int main()
{
	int a = 25;

	printf("The value of a is %d\n",a);
	a = a + 5;
	printf("The value of a is %d\n",a);
	a = a - 5;
	printf("The value of a is %d\n",a);
	a = a * 5;
	printf("The value of a is %d\n",a);
	a = a / 5;
	printf("The value of a is %d\n",a);

	return(0);
}
