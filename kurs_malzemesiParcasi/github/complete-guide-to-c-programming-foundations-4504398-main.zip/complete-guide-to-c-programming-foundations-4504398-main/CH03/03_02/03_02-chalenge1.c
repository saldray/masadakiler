#include <stdio.h>

int main()
{
	/* variable declarations */

	/* variable assignments */

	/* output */
	printf("Value of variable A = %d\n",a);
	printf("Value of variable B = %f\n",b);
	printf("value of vairable C = %d\n",c);

	return(0);
}
