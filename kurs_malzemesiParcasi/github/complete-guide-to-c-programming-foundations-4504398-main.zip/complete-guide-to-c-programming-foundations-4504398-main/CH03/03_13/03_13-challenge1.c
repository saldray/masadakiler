#include <stdio.h>

int main()
{
	int a,b;

	printf("Enter two values, separated by a space: ");
	scanf("%d",&a);
	scanf("%d",&b);

	// add
	// subtract
	// multiply
	// divide
	// modulus
	// bit shift right
	// bit shift left

	return 0;
}
