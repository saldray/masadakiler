#include <stdio.h>

int main()
{
	int artifacts,rooms,paintings,sculptures;

	/* code your calculations here */

	printf("This museum has %d artifacts\n",artifacts);

	return(0);
}
