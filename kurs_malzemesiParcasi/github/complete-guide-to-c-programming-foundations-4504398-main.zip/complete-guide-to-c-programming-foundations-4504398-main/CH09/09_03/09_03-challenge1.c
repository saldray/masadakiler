#include <stdio.h>

int main()
{
	const char filename[] = "hello.txt";

	return 0;
}
