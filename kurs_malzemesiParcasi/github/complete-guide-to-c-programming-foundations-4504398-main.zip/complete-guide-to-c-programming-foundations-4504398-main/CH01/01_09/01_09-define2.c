#include <stdio.h>

#define GREETING "Howdy do!"

int main()
{
	puts(GREETING);
	return 0;
}
