#include <stdio.h>

#define charout(a) putc(a,stdout)

int main()
{
	charout('H');
	charout('i');
	charout('!');
	charout('\n');
	return 0;
}
