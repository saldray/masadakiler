#include <stdio.h>

int main()
{
	char happy_face = 191;	/* isn't this the correct code? */

	puts("I can generate text all day long.");
	/* printf("%c\n",happy_face); */

	return(0);
}

