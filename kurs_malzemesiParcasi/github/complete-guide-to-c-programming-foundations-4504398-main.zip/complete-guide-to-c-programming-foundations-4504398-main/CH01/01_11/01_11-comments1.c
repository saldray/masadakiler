/*
   This code outputs a message
*/
#include <stdio.h>	//You can add this type of comment at the end of a line

/* This code contains only the main() function */
int main()
{
	puts("I can generate text all day long.");	/* pithy advice */

	return(0);
}
