#include <stdio.h>

int main()
{
	puts("This string /* char array */ is too long");

	return(0);
}

