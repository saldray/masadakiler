#include <stdio.h>
#include <stdlib.h>

/* main program */
int main()
{
	/* initialization */

	/* initial message */

	/* main program loop */

	/* output results */

	return 0;
}
