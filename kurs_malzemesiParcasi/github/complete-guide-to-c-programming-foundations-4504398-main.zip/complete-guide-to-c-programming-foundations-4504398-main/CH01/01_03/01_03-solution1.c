#include <stdio.h>

int main()
{
	puts("I am a C programmer.");

	return 0;
}
