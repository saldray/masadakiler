main program
 
initialization

initial message

main program loop

output results
