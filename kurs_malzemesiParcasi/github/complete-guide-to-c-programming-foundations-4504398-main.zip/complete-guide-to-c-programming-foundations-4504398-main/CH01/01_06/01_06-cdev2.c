#include <stdio.h>

int main()
{
	printf("I bet you can ")
	prinft("find the error!\n");
	return 0;
}
