#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

/* main program */
int main()
{
	// variable declaration

	while(1)
	{
		printf("Command: ");
		// fetch input
		// remove newline
		// convert to uppercase
		// output "Processing command 'cmd'"
		// break the loop on `QUIT`
	}

	return 0;
}
