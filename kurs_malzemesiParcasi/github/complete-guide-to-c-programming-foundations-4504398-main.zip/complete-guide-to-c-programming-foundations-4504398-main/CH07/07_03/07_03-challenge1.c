#include <stdio.h>

int main()
{
	char string[] = "Nifty TEXT! 123\n";

	return(0);
}
