#include <stdio.h>

int main()
{
	char string[] = "Yet another string literal";

	printf("A string literal");
	printf(string);

	return(0);
}

