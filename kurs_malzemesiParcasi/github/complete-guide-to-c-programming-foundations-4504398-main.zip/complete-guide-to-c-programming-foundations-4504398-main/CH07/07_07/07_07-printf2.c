#include <stdio.h>

int main()
{
	char string[] = "Yet another string literal\n";

	printf("A string literal\n");
	printf("%s",string);

	return(0);
}

