#include <stdio.h>

int main()
{
	printf("%f\n",2.5E6);
	printf("%f\n",2.5e-6);

	return(0);
}
