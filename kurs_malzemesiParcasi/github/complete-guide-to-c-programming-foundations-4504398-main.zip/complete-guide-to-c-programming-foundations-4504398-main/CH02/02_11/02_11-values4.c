#include <stdio.h>

int main()
{
	long x = 100L;
	unsigned y = 17U;
	float z = 3.0F;

	printf("X = %ld\n",x);
	printf("Y = %d\n",y);
	printf("Z = %f\n",z);
	return 0;
}
