#include <stdio.h>

int main()
{
	printf("Here is the value of A: %d\n",a);
	printf("Here is the value of B: %c\n",b);

	return(0);
}
