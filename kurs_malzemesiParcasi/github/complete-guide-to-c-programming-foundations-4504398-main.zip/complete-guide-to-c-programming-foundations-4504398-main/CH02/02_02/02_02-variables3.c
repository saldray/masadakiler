#include <stdio.h>

int main()
{
	char a = 'X';
	int count = 25;
	double longitude = 47.677878;

	printf("%c\n%d\n%f\n",
			a,
			count,
			longitude
		  );
	return 0;
}
