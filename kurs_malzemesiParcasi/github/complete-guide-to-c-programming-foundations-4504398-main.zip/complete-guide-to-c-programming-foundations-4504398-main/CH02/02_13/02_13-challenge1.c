#include <stdio.h>
#include <stdlib.h>

int main()
{
	//declare constant ratio equal to 3/4
	//declare char a
	//declare integer b
	//declare float c

	//assign char
	//assign integer
	//assign float

	//output char value, e.g., "the value of variable a is '?'"
	//output integer value, e.g., "the value of variable b is ??"
	//output float value, e.g., "the value of variable c is ???.??"
	//output value of ratio, e.g., "the value of constant ratio is ???.??"

	return 0;
}
