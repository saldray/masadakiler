#include <stdio.h>

int main()
{
	float x;

	printf("The value of %f is unknown\n",x);

	return(0);
}
