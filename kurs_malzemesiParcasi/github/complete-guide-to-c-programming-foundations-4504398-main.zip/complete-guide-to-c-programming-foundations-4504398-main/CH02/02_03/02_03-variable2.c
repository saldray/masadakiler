#include <stdio.h>

int main()
{
	char a = 'A';
	int b = 2;
	float c = 0.25;
	double d = 2500000.0;

	printf("a is %c\n",a);
	printf("b is %d\n",b);
	printf("c is %f\n",c);
	printf("d is %f\n",d);

	return(0);
}
