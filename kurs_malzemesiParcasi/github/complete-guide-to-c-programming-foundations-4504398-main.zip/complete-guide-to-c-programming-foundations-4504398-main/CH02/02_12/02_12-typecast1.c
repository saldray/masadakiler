#include <stdio.h>

int main()
{
	int a,b;

	a = 100;
	b = 7;

	printf("%d / %d = %d\n",a,b,a/b);

	return(0);
}
