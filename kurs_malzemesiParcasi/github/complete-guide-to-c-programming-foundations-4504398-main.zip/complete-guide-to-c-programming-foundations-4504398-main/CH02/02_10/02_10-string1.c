#include <stdio.h>

int main()
{
	char string[] = "I'm literally a string.\n";

	puts(string);
}
