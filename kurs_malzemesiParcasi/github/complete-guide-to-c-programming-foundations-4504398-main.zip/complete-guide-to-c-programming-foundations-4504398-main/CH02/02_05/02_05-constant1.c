#include <stdio.h>

int main()
{
	int a;

	a = 4+5;
	printf("4 + 5 = %d\n",a);

	return(0);
}
