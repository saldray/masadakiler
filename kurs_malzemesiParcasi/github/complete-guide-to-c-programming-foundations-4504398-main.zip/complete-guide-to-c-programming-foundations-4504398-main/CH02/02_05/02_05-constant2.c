#include <stdio.h>

int main()
{
	putchar('H');
	putchar('e');
	putchar('l');
	putchar('l');
	putchar('o');
	putchar('\n');

	return(0);
}
