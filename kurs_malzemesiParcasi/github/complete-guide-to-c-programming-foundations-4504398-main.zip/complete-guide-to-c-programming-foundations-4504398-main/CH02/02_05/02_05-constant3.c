#include <stdio.h>

int main()
{
	puts("Greetings, programmer!");

	return(0);
}

