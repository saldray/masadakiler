#include <stdio.h>

int main()
{
	int a = 16;
	const char b = 'Z';

	printf("Here is the value of A: %d\n",a);
	printf("Here is the value of B: %c\n",b);

	return(0);
}

