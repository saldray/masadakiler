#include <stdio.h>

int main()
{
	char ch = 'A';
	unsigned x = 100;
	float pi = 3.14159;

	printf("ch = %c, x = %u, pi = %f\n",ch,x,pi);
	return 0;
}
