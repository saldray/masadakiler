#include <stdio.h>

int main()
{
	float pi = 3.14159;

	printf("The value of pi: %.2f\n",pi);
	return 0;
}
