#include<stdio.h>

int main()
{
printf("The current month is January.\n");
printf("The current year is 2022.\n");
printf("I am a student at the University of Central Florida.\n");
printf("This Spring 2022, I am taking COP3223C Introduction to Programming with C with Dr. Steinberg.\n");
printf("I am super excited to learn the C Language this semester!\n");

return 0;
}


